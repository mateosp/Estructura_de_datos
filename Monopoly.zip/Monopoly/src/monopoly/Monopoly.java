package monopoly;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class Monopoly {

    public static void main(String[] args) {
        Principal ventana = new Principal();
        ventana.setVisible(true);
    }
}
